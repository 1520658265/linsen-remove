package com.xunjer.alinsen;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication()
public class AlinsenApplication {

    public static void main(String[] args) {
        SpringApplication.run(AlinsenApplication.class, args);
    }

}
