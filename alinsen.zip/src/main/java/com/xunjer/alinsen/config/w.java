package com.xunjer.alinsen.config;

/**
 * @author linsen
 * @date 2020/3/14 22:05
 * @tips 明日复明日 明日何其多
 */
public class w {
}
